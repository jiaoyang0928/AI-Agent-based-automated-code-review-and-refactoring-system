ai-code-reviewer/
├── README.md
├── requirements.txt
├── agent_core.py
├── tools.py
├── config.py
└── demo.py